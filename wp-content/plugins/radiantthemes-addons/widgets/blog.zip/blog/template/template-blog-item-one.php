<?php
/**
 * Template for Blog Item One.
 *
 * @package RadiantThemes
 */

// POST FORMAT STANDARD.
$output .= '<!-- blog-item -->';
$output .= '<article class="blog-item">';
$output .= '<div class="holder">';
$output .= '<div class="post-thumbnail">';
$output .='<img src="' . plugins_url( 'radiantthemes-addons/assets/images/No-Image-Found-400x264.png' ) . '" alt="Blank Image" width="400" height="240" data-no-retina="">';
$output .= ' <a class="placeholder" href="' . get_the_permalink() . '" style="background-image:url(' . get_the_post_thumbnail_url( get_the_ID(), 'medium_large' ) . ');"></a>'; 
 $output .= '</div>';
 $output .='<div class="post-data">';
                            $output .='<div class="entry-main matchHeight">';
         $output .= '<div class="date">';
   $output .='<h5><span>'. get_the_time('m') .' </span> '. get_the_time('M Y') .'</h5>';
$output .= '</div>';
$output .= '<header class="entry-header">';
$output .= '<p class="category">' . get_the_category( $query->ID )[0]->name .'</p>';
$output .= '<h3 class="entry-title"><a href="' . get_the_permalink() . '">' . get_the_title() . '</a>';
$output .= '</h3>';
$output .= '</header>';
$output .= '</div>';
$output .= '</div>';
$output .= '</div>';
$output .= '</article>';
$output .= '<!-- blog-item -->';

